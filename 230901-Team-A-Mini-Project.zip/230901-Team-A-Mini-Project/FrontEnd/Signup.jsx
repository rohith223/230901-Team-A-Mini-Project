import React, { useState, ChangeEvent, FormEvent } from "react";
import "./auth.css";
import Validation from "./SignupValidation";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import image from './pic.png';

function Signup() {
    const [values, setValues] = useState({
        Name: "",
        email: "",
        password: "",
        mobile:"",
        address:"",
        job:"",
        blood:"",
        hobby:""
    });
    const [errors, setErrors] = useState({
        Name: "",
        email: "",
        password: "",
        mobile:""
    });
    const navigate = useNavigate();

    const HandleInput = (event) => {
        setValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    };

    const HandleSubmit = (event) => {
        event.preventDefault();
        const validationErrors = Validation(values);
        setErrors(validationErrors );
        console.log(values);
        if (!validationErrors.Name && !validationErrors.email && !validationErrors.password && !validationErrors.mobile) {
            axios.post('http://localhost:8084/signup',values)
                .then(res => {
                    navigate('/');
                })
                .catch(err => console.log(err));
        }
    };

    return (
        <div className="reg-main-container">
            <div className="reg-image">
                <img src={image} alt="Registration" width={'849px'} />
            </div>
            <div className="reg-sub-container">
                <h1 className="registration-heading">Registration </h1>
                <form className="reg-form" onSubmit={HandleSubmit}>
                    <div>
                        <label htmlFor="name">Name : </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter Your name"
                            id="name"
                            onChange={HandleInput}
                            name="Name"
                            value={values.Name}
                        />
                        {errors.Name && <span className="text-danger">{errors.Name}</span>}
                    </div>
                    <div>
                        <label htmlFor="E-mail">E-mail : </label>
                        <br />
                        <input
                            type="email"
                            placeholder="Enter User name"
                            id="userName"
                            onChange={HandleInput}
                            name="email"
                            value={values.email}
                        />
                        {errors.email && <span className="text-danger">{errors.email}</span>}
                    </div>
                    <div>
                        <label htmlFor="password">Password : </label>
                        <br />
                        <input
                            type="password"
                            placeholder="Enter password"
                            id="password"
                            onChange={HandleInput}
                            name="password"
                            value={values.password}
                        />
                        {errors.password && <span className="text-danger">{errors.password}</span>}
                    </div>
                    <div>
                        <label htmlFor="mobile">Mobile-No : </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter Mobile number"
                            id="mobile"
                            onChange={HandleInput}
                            name="mobile"
                            value={values.mobile}
                        />
                    </div>
                    <div>
                        <label htmlFor="address">Address : </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter your Address"
                            id="address"
                            onChange={HandleInput}
                            name="address"
                            value={values.address}
                        />
                    </div>
                    <div>
                        <label htmlFor="job">Designation:  </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter your Designation"
                            id="job"
                            onChange={HandleInput}
                            name="job"
                            value={values.job}
                        />
                    </div>
                    <div>
                        <label htmlFor="blood">Blood Group:  </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter your Blood group"
                            id="blood"
                            onChange={HandleInput}
                            name="blood"
                            value={values.blood}
                        />
                    </div>
                    <div>
                        <label htmlFor="hobby">Hobby:  </label>
                        <br />
                        <input
                            type="text"
                            placeholder="Enter your hobby"
                            id="hobby"
                            onChange={HandleInput}
                            name="hobby"
                            value={values.hobby}
                        />
                    </div>
                    <button type="submit" className="reg-button">
                        Register
                    </button>
                </form>
            </div>
        </div>
    );
}

export default Signup;
