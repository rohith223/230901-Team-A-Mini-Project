import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './project.css';
import logo from './logo2.png'; // Import the image

function Projects() {
  const [isTableOpen, setTableOpen] = useState(false);

  const toggleTable = () => {
    setTableOpen(!isTableOpen);
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <div className="col-2 sidenav">
          <a className="nav-link text-white" href="#">
            <img src={logo} alt="Logo" width="25" height="35" />
          </a>
          <a href="#dashboard">Dashboard</a>
          <a href="">Project Allocation</a>
          <a href="bday">Upcoming Events</a>
          {/* ... (sidebar content) */}
          <div className="nav-bottom">
            <span className="bi">Christopher</span>
            <i class="bi bi-box-arrow-right"></i>
          </div>
        </div>

        {/* Content Area */}
        <div className="col-10" style={{ paddingLeft: '120px', paddingTop: '10px' }}>
          <div className="container" style={{ marginLeft: '110px' }}>
            <h6
              id="tableHeader"
              className="text-white p-2"
              style={{ backgroundColor: '#19105B', cursor: 'pointer' }}
              onClick={toggleTable}
            >
              Allocation Extension
            </h6>
            {isTableOpen && (
              <div className="dropdown-table">
                <table className="table">
                  <thead>
                    <tr style={{ backgroundColor: '#e8b5dc' }}>
                      <th style={{ color: '#200580', backgroundColor: '#FFE5EE' }}>Project name</th>
                      <th style={{ color: '#200580', backgroundColor: '#FFE5EE' }}>Project type</th>
                      <th style={{ color: '#200580', backgroundColor: '#FFE5EE' }}>Project end date</th>
                      <th style={{ color: '#200580', backgroundColor: '#FFE5EE' }}>Allocation end date</th>
                      <th style={{ color: '#200580', backgroundColor: '#FFE5EE' }}>Allocation Extension</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>BAU</td>
                      <td>internal Project</td>
                      <td>14-08-2023</td>
                      <td>15-08-2023</td>
                      <td>
                        <div className="sd-container">
                          <input className="sd" type="date" name="selected_date" />
                          <span className="open-button">
                            <button type="button">📅</button>
                          </span>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>BAU-1</td>
                      <td>client Project</td>
                      <td>24-08-2023</td>
                      <td>25-08-2023</td>
                      <td>
                        <div className="sd-container">
                          <input className="sd" type="date" name="selected_date" />
                          <span className="open-button">
                            <button type="button">📅</button>
                          </span>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Projects;
