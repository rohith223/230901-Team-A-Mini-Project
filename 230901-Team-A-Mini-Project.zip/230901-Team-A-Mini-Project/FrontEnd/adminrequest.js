// EventForm.js
import React, { useState } from 'react';
import './adminrequest.css';
import axios from 'axios';

const EventForm = () => {
    const [eventName, setEventName] = useState('');
    const [eventDate, setEventDate] = useState('');
    const [eventTime, setEventTime] = useState('');
    const [eventVenue, setEventVenue] = useState('');
    const [isPopupVisible, setIsPopupVisible] = useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      // Perform any submission logic here
      const eventData = {
        event_name: eventName,
        date: eventDate,
        time: eventTime,
        venue: eventVenue,
      };

      try {
        // Make a POST request to your backend
        const response = await axios.post('http://localhost:5000/dashboard/upcoming_event', eventData)
        .then((d)=>{
          console.log(d)
        }).catch((err)=>{
          console.log(err)
        }); // Adjust the API endpoint

        // Handle the response if needed
        console.log('Server response:', response.data);
        alert('created')

        // Clear the form data and hide the popup
        setEventName('');
        setEventDate('');
        setEventTime('');
        setEventVenue('');
        setIsPopupVisible(false);
      } catch (error) {
        console.error('Error adding event:', error);
        // Handle the error here
      }
    };
  
    const togglePopup = () => {
      setIsPopupVisible(!isPopupVisible);
    };
    
  return (
    <div className="event-form">
    <button className="admin-request-button" onClick={togglePopup}>Open Form</button>

    <div className={`popup ${isPopupVisible ? 'active' : ''}`}>
      <h2>Create Event</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="eventName" ></label>
        <input
          type="text"
          id="eventName"
          value={eventName}
          placeholder='Event name'
          onChange={(e) => setEventName(e.target.value)}
          required
        />

        <label htmlFor="eventDate"></label>
        <input
          type="date"
          id="eventDate"
          value={eventDate}
          onChange={(e) => setEventDate(e.target.value)}
          required
        />

        <label htmlFor="eventTime"></label>
        <input
          type="time"
          id="eventTime"
          value={eventTime}
          placeholder='Time'
          onChange={(e) => setEventTime(e.target.value)}
          required
        />

        <label htmlFor="eventVenue"></label>
        <input
          type="text"
          id="eventVenue"
          value={eventVenue}
          placeholder='Venue'
          onChange={(e) => setEventVenue(e.target.value)}
          required
        />

        <button className="addeventbtn" type="submit">Add Event</button>
        </form>
      </div>
    </div>
  );
};


export default EventForm;
