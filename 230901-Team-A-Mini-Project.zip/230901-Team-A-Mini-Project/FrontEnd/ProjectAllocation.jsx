import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './project.css';
import logo from './logo2.png'; // Import the image

function TimesheetApproval() {
  return (
    <div className="sidenav">
      <a className="nav-link text-white" href="#"><img src={logo} alt="Logo" width="25" height="35" /></a>
      <a href="#dashboard">Dashboard</a>
      <a href="project">Project Allocation</a>
      <a href="bday"> Events</a>
      <div className="nav-bottom">
        <span className="bi">Christopher</span>
        <i className="bi bi-box-arrow-in-right"></i>
      </div>
    </div>
  );
}

export default TimesheetApproval;
