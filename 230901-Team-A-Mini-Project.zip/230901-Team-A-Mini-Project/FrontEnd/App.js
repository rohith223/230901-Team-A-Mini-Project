import './App.css';
import {BrowserRouter, Routes, Route } from 'react-router-dom';
import Projects from './Project';
import TimesheetApproval from './ProjectAllocation';
import Empbday from './Bdaycomp';
import Login from './login';
import Signup from './Signup';
import AdminEvent from './Adminevents';
import AdminHoliday from './AdminHoliday';
import HldForm from './hdl';
import AdminTimesheetApproval from './AdminProjectAllocation';
import EventForm from './adminrequest';


function App() {
  return (
    <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/registration" element={<Signup />} /> 
          <Route path="/user" element={<TimesheetApproval />} />
          <Route path="/project" element={<Projects />} /> 
          <Route path="/bday" element={<Empbday />} /> 

          <Route path="/Adminevent" element={<AdminEvent />} /> 
          <Route path="/AdminHoliday" element={<AdminHoliday />} /> 
          <Route path="/HldForm" element={<HldForm />} /> 
          <Route path="/AdminTime" element={<AdminTimesheetApproval />} /> 
          <Route path="/EventForm" element={<EventForm />} /> 
        </Routes>
        </BrowserRouter>
       
  );
}

export default App;
