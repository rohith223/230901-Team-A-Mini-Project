import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import logo from './logo2.png'; // Import the image
import'./project.css';

function AdminTimesheetApproval(){
  return (
    <div className="sidenav">
      <a className="nav-link text-white" href="#"><img src={logo} alt="Logo" width="25" height="35" /></a>
      <a href="#dashboard">Dashboard</a>
      <a href="Adminevent">events</a>
  <div class="nav-bottom">
    <span class="bi">Christopher</span>
    <i class="bi bi-box-arrow-right"></i>
</div>
    </div>
  );
}

export default AdminTimesheetApproval;