import React, { useState } from 'react';
import axios from 'axios';

const HldForm = () => {
  const [holidayName, setHolidayName] = useState('');
  const [holidayDate, setHolidayDate] = useState('');
  const [isPopupVisible, setIsPopupVisible] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Create an object with holiday data
    const holidayData = {
      name: holidayName,
      date: holidayDate,
    };

    try {
      // Make a POST request to your server
      const response = await axios.post('/api/addHoliday', holidayData); // Adjust the API endpoint

      // Handle the response if needed
      console.log('Server response:', response.data);
      alert("Holiday added successfully");
      setHolidayName('');
      setHolidayDate('');
      setIsPopupVisible(false);
    } catch (error) {
      console.error('Error adding holiday:', error);
      // Handle the error here
    }

  };
  const togglePopup = () => {
    setIsPopupVisible(!isPopupVisible);
  };

  return (
    <div className="event-form">
      <button className="admin-request-button1" onClick={togglePopup}>
        Open Form
      </button>

      <div className={`popup ${isPopupVisible ? 'active' : ''}`}>
      <form onSubmit={handleSubmit}>
        <h2>Add Holiday</h2>
          <label htmlFor="holidayName"></label>
          <input
            type="text"
            id="holidayName"
            value={holidayName}
            placeholder='Name'
            onChange={(e) => setHolidayName(e.target.value)}
            required
          />

          <label htmlFor="holidayDate"></label>
          <input
            type="date"
            id="Date"
            value={holidayDate}
            onChange={(e) => setHolidayDate(e.target.value)}
            required
          />

          <button className="addeventbtn" type="submit">Add Holiday</button>
        </form>
      </div>
    </div>
  );
};

export default HldForm;