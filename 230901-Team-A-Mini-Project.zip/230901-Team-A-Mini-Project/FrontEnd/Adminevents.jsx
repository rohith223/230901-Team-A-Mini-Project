import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './project.css';
import EventForm from './adminrequest';
//import axios from 'axios';
//import { useEffect } from 'react';
import './adminrequest.css'
import HldForm from './hdl';
import PopUp from './AdminHoliday';
import logo from './logo2.png'; // Import the image

function AdminEvent() {
  const [isTableOpen, setTableOpen] = useState(false);
  const toggleTable = () => {
    setTableOpen(!isTableOpen);
};

const sampleEventData = [
    {
      id: 1,
      date: '2023-09-15',
      event_name: 'Sample Event 1',
      description: 'This is the first sample event',
      time: '14:00',
      venue: 'Sample Venue 1'
    },
    {
      id: 2,
      date: '2023-09-20',
      event_name: 'Sample Event 2',
      description: 'This is the second sample event',
      time: '18:30',
      venue: 'Sample Venue 2'
    }
  ];
  const [events, setEvents] = useState(sampleEventData);

//    useEffect(() => {
//     const [events, setEvents] = useState(sampleEventData);
// //     axios.get('API_ENDPOINT_HERE')
// //       .then(response => {
// //         setEvents(response.data); // Assuming the API response contains the events data
// //       })
// //       .catch(error => {
// //         console.error('Error fetching events:', error);
// //       });
//    }, []);

  return (
    <>
        <div className="sidenav">
      <a className="nav-link text-white" href="#"><img src={logo} alt="Logo" width="25" height="35" /></a>
      <a href="#dashboard">Dashboard</a>
      <a href="event">add Events</a>
  <div class="nav-bottom">
    <span class="bi">Christopher</span>
    <i class="bi bi-box-arrow-right"></i>
</div>
    </div>
        <div className="col-10 container-fluid row" style={{ paddingLeft: '120px', paddingTop: '10px' }}>
          <div className="container" style={{ marginLeft: '110px' }}>
            <h6
              id="tableHeader"
              className="text-white p-2"
              style={{ backgroundColor: '#200580', cursor: 'pointer' }}
              onClick={toggleTable}
            >
              Upcomming Events
            </h6>
            {isTableOpen && (
              <div className="dropdown-table">
                <table className="table">
                  <thead>
                    <tr style={{ backgroundColor: '#e8b5dc' }}>
                      <th style={{ color: '#200580' }}>Date</th>
                      <th style={{ color: '#200580' }}>Event Name</th>
                      <th style={{ color: '#200580' }}>Description</th>
                      <th style={{ color: '#200580' }}>Time</th>
                      <th style={{ color: '#200580' }}>Venue</th>
                    </tr>
                  </thead>
                  <tbody>
                    {events.map(event => (
                    <tr key={event.id}>
                    <td>{event.date}</td>
                    <td>{event.event_name}</td>
                    <td>{event.description}</td>
                    <td>{event.time}</td>
                    <td>{event.venue}</td>
                    </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
        <EventForm />
        <HldForm />
        <PopUp/>
        </>
  );

}
export default AdminEvent;