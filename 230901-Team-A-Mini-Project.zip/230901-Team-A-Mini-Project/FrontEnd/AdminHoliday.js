import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './project.css';
import axios from 'axios';
import { useEffect } from 'react';

function AdminHoliday() {
  const [isTableOpen, setTableOpen] = useState(false);
  const toggleTable = () => {
    setTableOpen(!isTableOpen);
  };
  const [Holidays, setHolidays] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:8085/api/publicholidays')
      .then(response => {
        setHolidays(response.data);
        console.log(response);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
    }, []);

  return (
        <div className="col-10 container-fluid row" style={{ paddingLeft: '120px', paddingTop: '10px' }}>
          <div className="container" style={{ marginLeft: '110px' }}>
            <h6
              id="tableHeader"
              className="text-white p-2"
              style={{ backgroundColor: '#200580', cursor: 'pointer' }}
              onClick={toggleTable}
            >
            Public Holidays
            </h6>
            {isTableOpen && (
              <div className="dropdown-table">
                <table className="table">
                  <thead>
                    <tr style={{ backgroundColor: '#e8b5dc' }}>
                      <th style={{ color: '#200580' }}>Date</th>                      
                      <th style={{ color: '#200580' }}>Description</th>                
                    </tr>
                  </thead>
                  <tbody>
                   {Holidays.map(holiday => (
                        <tr key={holiday.date} className="allocation-extension-row">
                          <td>{new Date(holiday.date).toISOString().split('T')[0]}</td>
                          <td>{holiday.description}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
  );
}

export default AdminHoliday;