import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './project.css';
import axios from 'axios';
import logo from './logo2.png';

function Event() {
  const [isTableOpen, setTableOpen] = useState(false);
  const [events, setEvents] = useState(sampleEventData);
  const [events, setEvents] = useState('');
  const navigate = useNavigate()

  const toggleTable = () => {
    setTableOpen(!isTableOpen);
  };

  const sampleEventData = [
    {
      id: 1,
      date: '2023-09-15',
      event_name: 'Sample Event 1',
      description: 'This is the first sample event',
      time: '14:00',
      venue: 'Sample Venue 1'
    },
    {
      id: 2,
      date: '2023-09-20',
      event_name: 'Sample Event 2',
      description: 'This is the second sample event',
      time: '18:30',
      venue: 'Sample Venue 2'
    }
  ];

  
  useEffect(() => {

    

    axios.get('http://localhost:5000/upcoming_event/get')

      .then(response => {

        setEvents(response.data); // Assuming the API response contains the events data

      })

      .catch(error => {

        console.error('Error fetching events:', error);

      });

   }, []);
  return (
    <div className="container-fluid">
      <h1 className='head'>Events</h1>
      <div className="sidenav">
        <a className="nav-link text-white" href="#">
          <img src={logo} alt="Logo" width="25" height="35" />
        </a>
        <a href="#dashboard">Dashboard</a>
        <a href="project">Project Allocation</a>
        <a href="bday">Upcoming Events</a>

        <div class="nav-bottom">
    <span class="bi" >Christopher</span>
    <i class="bi bi-box-arrow-right"></i>
</div>
      </div>
      <div className="col-10 container-fluid" style={{ paddingLeft: '60px', paddingTop: '15px' }}>
        <div className="container" style={{ marginLeft: '50px' }}>
          <h6
            id="tableHeader"
            className="text-white p-2"
            style={{ backgroundColor: '#19105B', cursor: 'pointer' }}
            onClick={toggleTable}
          >
            Upcoming Events
          </h6>
          {isTableOpen && (
            <div className="dropdown-table">
              <table className="table">
                <thead>
                  <tr style={{ backgroundColor: '#rgb(29, 5, 95)' }}>
                    <th style={{ color: '#200580' ,backgroundColor:'#FFE5EE'}}>Date</th>
                    <th style={{ color: '#200580' ,backgroundColor:'#FFE5EE' }}>Event Name</th>
                    <th style={{ color: '#200580' ,backgroundColor:'#FFE5EE'}}>Description</th>
                    <th style={{ color: '#200580' ,backgroundColor:'#FFE5EE' }}>Time</th>
                    <th style={{ color: '#200580' ,backgroundColor:'#FFE5EE'}}>Venue</th>
                  </tr>
                </thead>
                <tbody>
                  {events.map(event => (
                    <tr key={event.id}>
                      <td>{event.date}</td>
                      <td>{event.event_name}</td>
                      <td>{event.description}</td>
                      <td>{event.time}</td>
                      <td>{event.venue}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Event;
