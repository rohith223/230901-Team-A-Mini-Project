import React, { useState, useEffect } from 'react';
import './Bdaycomp.css'
import Event from './events';
import Holiday from './holiday';
import 'bootstrap/dist/css/bootstrap.min.css';
const Empbday = () => {
  const EmployeeData = [
    {
        empid:'Jmd211',
        name:'Abc',
        designation:' Software Engineer',
        birthdate:'2000-01-02'
    },

    {
        empid:'Jmd210',
        name:'Def',
        designation:' Sr. Software Engineer',
        birthdate:'1999-02-31'
    },
    {
        empid:'Jmd219',
        name:'Ankit',
        designation:'Software Engineer',
        birthdate:'2002-08-1'
    },
    {
        empid:'Jmd213',
        name:'Krishna',
        designation:'Product manager',
        birthdate:'1998-08-3'
    }
  ];

  const [todaysBdays, setTodaysBdays] = useState([]);

  useEffect(() => {
    const today = new Date();
    const filteredBirthdays = EmployeeData.filter(employee => {
      const birthdate = new Date(employee.birthdate);
      return (
        birthdate.getMonth() === today.getMonth() &&
        birthdate.getDate() === today.getDate()
      );
    });

    setTodaysBdays(filteredBirthdays);
  }, [EmployeeData]);

  return (
   <>
    <div className='birthday-card'>
      {todaysBdays.length === 0 ? (
        <p className='card-message'>No birthdays today !</p>
      ) : (
        <div id='birthday-carousel' className='carousel slide' data-bs-ride='carousel' data-bs-interval='2000'>
          <div className='carousel-inner'>
            {todaysBdays.map((employee, index) => (
              <div
                key={index}
                className={`carousel-item ${index === 0 ? 'active' : ''}`}
              >
                <div className='card-item'>
                  <h2 className='card-title'>Happy Birthday {employee.name} !</h2>
                  <p className='card-info'>{employee.designation}</p>
                  <p className='wish'>
                    "Wishing you all the best for your career journey ahead!"
                  </p>
                </div>
              </div>
            ))}
          </div>
          <a
            className='carousel-control-prev'
            href='#birthday-carousel'
            role='button'
            data-bs-slide='prev'
          >
            <span className='carousel-control-prev-icon' aria-hidden='true'></span>
            <span className='visually-hidden'>Previous</span>
          </a>
          <a
            className='carousel-control-next'
            href='#birthday-carousel'
            role='button'
            data-bs-slide='next'
          >
            <span className='carousel-control-next-icon' aria-hidden='true'></span>
            <span className='visually-hidden'>Next</span>
          </a>
        </div>
      )}
      
    </div>
    <Event></Event>
    <Holiday />
    </>
  );
};

export default Empbday;