module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  PORT: "3306",
  DATABASE: "training_project_db",
  DIALECT: "mysql",
};
